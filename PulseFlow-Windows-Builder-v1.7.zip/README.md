# Production Report Generator — Windows EXE

這個專案會自動建置不需要安裝 Python 的 Windows 執行檔 `PulseFlow.exe`。

## 最簡單方式：GitHub Actions

1. 在 GitHub 建立一個新的 repository。
2. 將此資料夾內所有檔案與 `.github/workflows/build-windows.yml` 上傳到 repository。
3. 開啟 GitHub 的 **Actions** 分頁。
4. 選擇 **Build Windows EXE**，按 **Run workflow**。
5. 工作完成後，從 workflow 的 **Artifacts** 下載 `PulseFlow-Windows.zip`。
6. 解壓縮後直接雙擊 `PulseFlow.exe`，不需要安裝 Python。

若建立 Git tag，例如 `v1.0.0`，也會自動觸發建置。

## Windows 本機建置

如果電腦上已有 Python，管理者可在 PowerShell 執行：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\\build_windows_exe.ps1
```

完成後，執行檔會在 `release\\PulseFlow.exe`。

## EXE 使用方式

1. 雙擊 `PulseFlow.exe`。
2. 選擇放置 CSV 的資料夾。
3. 選擇輸出資料夾。
4. 輸入報告檔名前綴。
5. 按「產生報告」。

輸出會包含 PDF、Excel 及 PNG 缺點分布圖。

## 注意事項

- CSV 必須符合目前檢驗報告格式。
- Windows Defender 第一次啟動未簽章的自行建置 EXE 時，可能顯示 SmartScreen 警告；請確認檔案來源後選擇「仍要執行」。
- 建置套件內含 Noto Sans CJK 字型，用於 PDF 與圖表的繁體中文顯示。

## v1.1 更新：報表指標與 AI 缺陷檔匯入

報表首頁 6 個指標：

1. 首檢條數 / 複檢條數 / 總條數（首檢＝只檢驗一次且非 NF；複檢＝其餘；兩者相加＝總條數）
2. 總缺點數 / 條平均缺點數（只計 NG、NF 不計；＝NG 總點數 ÷ 總條數）**最重要**
3. 正面條平均點數 / 背面條平均點數（A、B 面 NG 點數 ÷ 總條數）
4. 檢驗開始・結束時間 / 實際檢驗時間（稼動率 ＝ 實際檢驗時間 ÷ 開始至結束經過時間）
5. CTAvgTime / CTNowTime（取自 AutoRunCTAvgTime / AutoRunCTNowTime）
6. 最主要缺陷 位置/類型（例如 Metal / Discolor；來自 AI 缺陷檔）

### AI 缺陷檔（選填）

在程式「AI 檔資料夾」選擇路徑、「檔名樣式」輸入要抓的檔名（例如 `*.ai;AI*.csv`，可用 `*` `?`，多組以 `;` 分隔），
Step_Code 後 4 碼 = Strip ID，與主報表比對。報表會多出「缺陷類型分布」（前五項＋其他）、「AI缺陷比對」、「缺陷位置」工作表。
不選 AI 資料夾也可正常產生報表，只是缺陷位置/類型欄位會顯示「未匯入」。
