ProductionReportGenerator.exe

雙擊此檔案啟動應用程式。
選擇 CSV 資料夾與輸出資料夾後，按「產生報告」。

輸出：PDF、Excel、缺點分布圖 PNG。
不需要安裝 Python。
