import csv
import io
import os
import re
import sys
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from openpyxl import Workbook, load_workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

BASE = Path('/home/ubuntu/production_report_226926131000')
BASE.mkdir(parents=True, exist_ok=True)
ZIP_PATH = Path('/home/ubuntu/upload/226926131000.zip')
XLSX_PATH = BASE / '226926131000_簡易生產報告.xlsx'
PDF_PATH = BASE / '226926131000_簡易生產報告.pdf'
CHART_PATH = BASE / '226926131000_缺點分布圖.png'


REPORT_TITLE = '簡易生產報告'


def configure_paths(input_zip, output_dir, report_stem='生產報告'):
    """讓桌面應用程式或其他呼叫端指定來源 ZIP 與輸出資料夾。"""
    global BASE, ZIP_PATH, XLSX_PATH, PDF_PATH, CHART_PATH, REPORT_TITLE
    REPORT_TITLE = report_stem
    BASE = Path(output_dir)
    BASE.mkdir(parents=True, exist_ok=True)
    ZIP_PATH = Path(input_zip)
    XLSX_PATH = BASE / f'{report_stem}.xlsx'
    PDF_PATH = BASE / f'{report_stem}.pdf'
    CHART_PATH = BASE / f'{report_stem}_缺點分布圖.png'

# Traditional Chinese font for chart/report rendering. When bundled by
# PyInstaller, prefer the font copied into the application directory.
_font_candidates = [
    Path(getattr(sys, '_MEIPASS', '')) / 'NotoSansCJK-Regular.ttc',
    Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'),
]
_font_path = next((p for p in _font_candidates if p.exists()), None)
if _font_path:
    try:
        font_manager.fontManager.addfont(str(_font_path))
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=str(_font_path)).get_name()
    except Exception:
        plt.rcParams['font.family'] = 'Noto Sans CJK TC'
else:
    plt.rcParams['font.family'] = 'Noto Sans CJK TC'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42


SKIPPED_FILES = []


def decode_bytes(raw):
    """依序嘗試 UTF-8(BOM) 與 Big5/CP950，避免中文 Windows 匯出的檔案亂碼。"""
    for enc in ('utf-8-sig', 'cp950'):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode('utf-8', errors='replace')


def clean_code(s):
    return ' '.join((s or '').split())


UNREADABLE_ID = 'FAILED'


def split_2d_code(code):
    """拆解 2D Code，回傳 (批號部分, 4 位數 Strip ID)。

    規則：ISO 前面隔一個空格，抓空格前的 4 位數字。
    例：'22662105-000 1301  ISO Level: A' -> ('22662105-000', '1301')
    讀取失敗（例如 'FAILED  ISO Level: ERROR'）回傳 (None, None)，不中斷報表。
    """
    text = clean_code(code)
    m = re.search(r'(?<!\d)(\d{4})\s+ISO\b', text, re.IGNORECASE)
    if m:
        return text[:m.start()].strip(), m.group(1)
    m = re.search(r'^(\S+)\s+(\d{4})(?:\s|$)', text)   # 舊格式備援：批號 空格 4 位數
    if m:
        return m.group(1), m.group(2)
    return None, None


def strip_id_from_code(code):
    """回傳 4 位數 Strip ID（文字，保留前導零）；無法辨識回傳 None。"""
    return split_2d_code(code)[1]


def pair_value(text):
    m = re.search(r'\((\d+)\s*/\s*(\d+)\)', text or '')
    return tuple(map(int, m.groups())) if m else (0, 0)


def to_int(meta, key, default=0):
    try:
        return int(str(meta[key][0]).strip())
    except (KeyError, IndexError, ValueError):
        return default


def to_float(text, default=0.0):
    m = re.search(r'[\d.]+', str(text or ''))
    return float(m.group()) if m else default


def parse_date_time(meta, key):
    values = meta[key]
    return datetime.strptime(''.join(str(v).strip() for v in values[:2]), '%Y%m%d%H%M%S')


def fmt_hms(seconds):
    seconds = int(round(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f'{h}:{m:02d}:{s:02d}'


def fmt_duration(seconds):
    seconds = int(round(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f'{h} 小時 {m} 分 {s} 秒'
    return f'{m} 分 {s} 秒'


def parse_archive():
    SKIPPED_FILES.clear()
    observations, batches = [], []
    with zipfile.ZipFile(ZIP_PATH) as zf:
        for filename in zf.namelist():
            if not filename.lower().endswith('.csv'):
                continue
            text = decode_bytes(zf.read(filename))
            rows = list(csv.reader(io.StringIO(text)))
            meta = {row[0].strip().rstrip(':'): row[1:]
                    for row in rows if row and row[0].strip()}
            if 'Inspection Start Date' not in meta:
                # 不是檢驗摘要 CSV（例如 AI 缺陷檔放在同一資料夾），略過。
                SKIPPED_FILES.append(filename)
                continue
            start = parse_date_time(meta, 'Inspection Start Date')
            end = parse_date_time(meta, 'Inspection End Date')
            if start > end:
                raise ValueError(f'時間起訖不合理：{filename}')
            b = {
                'file': filename,
                'product': meta.get('Material Name', [''])[0].strip(),
                'lot': meta.get('Lot Name', [''])[0].strip(),
                'operator': meta.get('Operator Name', [''])[0].strip(),
                'machine': meta.get('Machine Name', [''])[0].strip(),
                'start': start,
                'end': end,
                'strip_count': to_int(meta, 'Strip Number'),
                'strip_ng': to_int(meta, 'Strip Number NG'),
                'strip_nf': to_int(meta, 'Strip Number NF'),
                'strip_ok': to_int(meta, 'Strip Number OK'),
                'unit_count': to_int(meta, 'Total Unit Number'),
                'unit_ng': to_int(meta, 'Total Unit NG Number'),
                'unit_nf': to_int(meta, 'Total Unit NF Number'),
                'unit_ok': to_int(meta, 'Total Unit OK Number'),
                'side_a_ok': to_int(meta, 'SideA Unit OK Number'),
                'side_b_ok': to_int(meta, 'SideB Unit OK Number'),
                'reported_uph': to_float(meta.get('AutoRunCTAvgTime', [''])[0]),
                'current_uph': to_float(meta.get('AutoRunCTNowTime', [''])[0]),
                'rows': [],
            }
            batches.append(b)

            header_idx = next((i for i, row in enumerate(rows)
                               if row and row[0].strip() == 'Strip ID'), None)
            if header_idx is None:
                continue
            for row in rows[header_idx + 1:]:
                if len(row) < 8 or not row[0].strip().isdigit():
                    continue
                unit_a, unit_b = pair_value(row[2])
                defect_a, defect_b = pair_value(row[3])
                border_a, border_b = pair_value(row[4])
                status = row[6].strip().upper()
                if status not in {'NG', 'NF', 'OK'}:
                    status = status or '未標示'
                _lot, _sid = split_2d_code(row[1])
                if _sid:
                    _key = f'{_lot} {_sid}'
                else:
                    # 2D Code 讀取失敗：無法判斷是否為同一條，每筆視為獨立的條。
                    _sid = UNREADABLE_ID
                    _key = f'{UNREADABLE_ID} {filename} {row[0].strip()}'
                record = {
                    'file': filename,
                    'start': start,
                    'end': end,
                    # 顯示用 Strip ID 以 2D Code 中批號後 4 位數為準，不採用 CSV 第一欄的序號。
                    'strip_id': _sid,
                    'code': _key,
                    'raw_code': clean_code(row[1]),
                    'unit_a': unit_a,
                    'unit_b': unit_b,
                    'defect_a': defect_a,
                    'defect_b': defect_b,
                    'border_a': border_a,
                    'border_b': border_b,
                    'points': defect_a + defect_b,
                    'border_points': border_a + border_b,
                    'general_points': defect_a + defect_b - border_a - border_b,
                    'yield_pct': to_float(row[5].strip().replace('%', '')),
                    'status': status,
                    'remark': row[7].strip(),
                }
                if record['general_points'] < 0:
                    raise ValueError(f'邊緣缺點數大於總缺點數：{filename} / {record["code"]}')
                b['rows'].append(record)
                observations.append(record)
    batches.sort(key=lambda b: (b['start'], b['file']))
    observations.sort(key=lambda r: (r['start'], r['file'], r['strip_id']))
    if not batches or not observations:
        raise ValueError('ZIP 檔內找不到有效的檢驗 CSV 資料。')
    return batches, observations


def build_views(batches, observations):
    first_by_code, latest_by_code = {}, {}
    occurrence_counts = Counter(r['code'] for r in observations)
    for rec in observations:
        first_by_code.setdefault(rec['code'], rec)
        latest_by_code[rec['code']] = rec
    first_rows = list(first_by_code.values())
    latest_rows = list(latest_by_code.values())
    for rec in observations:
        rec['is_first'] = rec is first_by_code[rec['code']]
        rec['is_latest'] = rec is latest_by_code[rec['code']]
        rec['occurrence_no'] = sum(
            1 for earlier in observations
            if earlier['code'] == rec['code'] and
            (earlier['start'], earlier['file'], earlier['strip_id']) <=
            (rec['start'], rec['file'], rec['strip_id'])
        )
        rec['occurrence_count'] = occurrence_counts[rec['code']]
    # Determine first/latest markers by stable object identity and compute occurrence order efficiently.
    seq = Counter()
    for rec in observations:
        seq[rec['code']] += 1
        rec['occurrence_no'] = seq[rec['code']]

    first_rows.sort(key=lambda r: (r['start'], r['file'], r['strip_id']))
    latest_rows.sort(key=lambda r: (r['start'], r['file'], r['strip_id']))
    latest_for_code = latest_by_code
    first_nf = [r for r in first_rows if r['status'] == 'NF']
    first_ng = [r for r in first_rows if r['status'] != 'NF']
    latest_nf_excluded = [r for r in latest_rows if r['status'] != 'NF']
    rechecked_codes = {code for code, count in occurrence_counts.items() if count > 1}

    active_seconds = sum((b['end'] - b['start']).total_seconds() for b in batches)
    wall_seconds = (batches[-1]['end'] - batches[0]['start']).total_seconds()
    downtime_seconds = sum(
        max(0, (next_b['start'] - b['end']).total_seconds())
        for b, next_b in zip(batches, batches[1:])
    )
    longest_gap = max(
        [max(0, (next_b['start'] - b['end']).total_seconds())
         for b, next_b in zip(batches, batches[1:])] or [0]
    )
    all_strip_events = sum(b['strip_count'] for b in batches)
    all_unit_events = sum(b['unit_count'] for b in batches)
    device_equiv_uph = (
        all_strip_events /
        sum(b['strip_count'] / b['reported_uph'] for b in batches if b['reported_uph'] > 0)
    ) if all(b['reported_uph'] > 0 for b in batches) else None
    observed_event_uph = all_strip_events / (active_seconds / 3600)
    unique_output_uph = len(first_rows) / (active_seconds / 3600)

    first_def_a = sum(r['defect_a'] for r in first_ng)
    first_def_b = sum(r['defect_b'] for r in first_ng)
    first_unit_a = sum(r['unit_a'] for r in first_ng)
    first_unit_b = sum(r['unit_b'] for r in first_ng)
    latest_def_a = sum(r['defect_a'] for r in latest_nf_excluded)
    latest_def_b = sum(r['defect_b'] for r in latest_nf_excluded)
    exact_point_counts = Counter(r['points'] for r in first_ng)
    max_point_count = max(exact_point_counts.keys(), default=0)
    latest_unit_a = sum(r['unit_a'] for r in latest_nf_excluded)
    latest_unit_b = sum(r['unit_b'] for r in latest_nf_excluded)

    batch_by_file = {b['file']: b for b in batches}
    first_count_by_file = Counter(r['file'] for r in first_rows)
    first_nf_by_file = Counter(r['file'] for r in first_nf)
    for b in batches:
        b['duration_seconds'] = (b['end'] - b['start']).total_seconds()
        b['gap_before_seconds'] = 0
        b['first_pass_unique'] = first_count_by_file[b['file']]
        b['first_pass_nf'] = first_nf_by_file[b['file']]
        b['reinspection_rows'] = len(b['rows']) - b['first_pass_unique']
    for prev, curr in zip(batches, batches[1:]):
        curr['gap_before_seconds'] = max(0, (curr['start'] - prev['end']).total_seconds())

    # Verify all summary strip-row totals agree with file detail rows.
    for b in batches:
        if b['strip_count'] != len(b['rows']):
            raise ValueError(f'批次摘要條數與明細列不一致：{b["file"]}')

    stats = {
        'batches': batches,
        'observations': observations,
        'first_rows': first_rows,
        'latest_rows': latest_rows,
        'first_nf': first_nf,
        'first_ng': first_ng,
        'latest_ex_nf': latest_nf_excluded,
        'rechecked_codes': rechecked_codes,
        'occurrence_counts': occurrence_counts,
        'first_count': len(first_rows),
        'first_nf_count': len(first_nf),
        'first_ng_count': len(first_ng),
        'first_nf_rate': len(first_nf) / len(first_rows) if first_rows else 0,
        'event_count': all_strip_events,
        'unit_event_count': all_unit_events,
        'reinspection_rows': len(observations) - len(first_rows),
        'rechecked_unique_count': len(rechecked_codes),
        'start': batches[0]['start'],
        'end': batches[-1]['end'],
        'active_seconds': active_seconds,
        'wall_seconds': wall_seconds,
        'downtime_seconds': downtime_seconds,
        'longest_gap': longest_gap,
        'device_equiv_uph': device_equiv_uph,
        'observed_event_uph': observed_event_uph,
        'unique_output_uph': unique_output_uph,
        'first_def_a': first_def_a,
        'first_def_b': first_def_b,
        'first_points': first_def_a + first_def_b,
        'first_unit_a': first_unit_a,
        'first_unit_b': first_unit_b,
        'first_avg_a': first_def_a / first_unit_a if first_unit_a else 0,
        'first_avg_b': first_def_b / first_unit_b if first_unit_b else 0,
        'first_border_a': sum(r['border_a'] for r in first_ng),
        'first_border_b': sum(r['border_b'] for r in first_ng),
        'first_border_points': sum(r['border_points'] for r in first_ng),
        'first_general_points': sum(r['general_points'] for r in first_ng),
        'latest_def_a': latest_def_a,
        'latest_def_b': latest_def_b,
        'latest_points': latest_def_a + latest_def_b,
        'latest_unit_a': latest_unit_a,
        'latest_unit_b': latest_unit_b,
        'latest_avg_a': latest_def_a / latest_unit_a if latest_unit_a else 0,
        'latest_avg_b': latest_def_b / latest_unit_b if latest_unit_b else 0,
        'latest_border_points': sum(r['border_points'] for r in latest_nf_excluded),
        'latest_general_points': sum(r['general_points'] for r in latest_nf_excluded),
        'latest_status_counts': Counter(r['status'] for r in latest_rows),
        'first_status_counts': Counter(r['status'] for r in first_rows),
        'exact_point_distribution': [
            {'缺點點數': point,
             '條數': exact_point_counts.get(point, 0),
             '占首檢NG比例': exact_point_counts.get(point, 0) / len(first_ng) if first_ng else 0}
            for point in range(1, max_point_count + 1)
        ],
        'point_distribution': [
            {'區間': '0–10', '下限': 0, '上限': 10,
             '條數': sum(0 <= r['points'] <= 10 for r in first_ng)},
            {'區間': '11–20', '下限': 11, '上限': 20,
             '條數': sum(11 <= r['points'] <= 20 for r in first_ng)},
            {'區間': '21–30', '下限': 21, '上限': 30,
             '條數': sum(21 <= r['points'] <= 30 for r in first_ng)},
            {'區間': '31–40', '下限': 31, '上限': 40,
             '條數': sum(31 <= r['points'] <= 40 for r in first_ng)},
            {'區間': '41–50', '下限': 41, '上限': 50,
             '條數': sum(41 <= r['points'] <= 50 for r in first_ng)},
            {'區間': '51+', '下限': 51, '上限': None,
             '條數': sum(r['points'] >= 51 for r in first_ng)},
        ],
    }
    add_core_metrics(stats)
    return stats


# =====================================================================
#  核心指標（需求 1～5）
# =====================================================================
def add_core_metrics(stats):
    """依需求計算 6 大指標中的 1～5 項。

    * 以「批號 + 4 位 Strip ID」為唯一條。
    * 首檢條數＝只檢驗過一次且非 NF 的條；複檢條數＝其餘（含 NF、重複檢驗）；兩者相加＝總條數。
    * 缺點數只計 NG：每條取「最後一筆 NG 紀錄」的點數，NF 紀錄一律不計。
    * 條平均缺點數＝NG 總點數 ÷ 總條數（含 NF 後轉 NG、含無 NG 紀錄的條）。
    """
    by_code = {}
    for rec in stats['observations']:
        by_code.setdefault(rec['code'], []).append(rec)
    total = len(by_code)
    first_only = 0
    nf_strips = 0
    final_ng = {}
    for code, recs in by_code.items():
        if len(recs) == 1 and recs[0]['status'] != 'NF':
            first_only += 1
        if any(r['status'] == 'NF' for r in recs):
            nf_strips += 1
        ngs = [r for r in recs if r['status'] == 'NG']
        if ngs:
            final_ng[code] = ngs[-1]
    ng_rows = list(final_ng.values())
    ng_a = sum(r['defect_a'] for r in ng_rows)
    ng_b = sum(r['defect_b'] for r in ng_rows)
    batches = stats['batches']
    util = stats['active_seconds'] / stats['wall_seconds'] if stats['wall_seconds'] else 0
    # CT：以各批條數加權平均；CTNowTime 取最後一個批次
    weighted = [(b['reported_uph'], b['strip_count']) for b in batches if b['reported_uph'] > 0]
    ct_avg = (sum(v * n for v, n in weighted) / sum(n for _, n in weighted)) if weighted else 0.0
    ct_now = batches[-1]['current_uph']
    ct_now_mean = (sum(b['current_uph'] for b in batches) / len(batches)) if batches else 0.0

    points_list = [r['points'] for r in ng_rows]
    bins = [(0, 10), (11, 20), (21, 30), (31, 40), (41, 50), (51, 10 ** 9)]
    labels = ['0–10', '11–20', '21–30', '31–40', '41–50', '51+']
    point_distribution = [
        {'區間': lab, '條數': sum(lo <= p <= hi for p in points_list)}
        for (lo, hi), lab in zip(bins, labels)
    ]
    exact = Counter(points_list)
    exact_distribution = [
        {'缺點點數': k, '條數': exact.get(k, 0),
         '占NG條數比例': exact.get(k, 0) / len(ng_rows) if ng_rows else 0}
        for k in range(1, max(exact.keys(), default=0) + 1)
    ]
    stats.update({
        'core_total': total,
        'core_first': first_only,
        'core_recheck': total - first_only,
        'core_nf_strips': nf_strips,
        'unreadable_strips': sum(1 for c in by_code if c.startswith(UNREADABLE_ID + ' ')),
        'final_ng': final_ng,
        'ng_strip_count': len(ng_rows),
        'ng_points': ng_a + ng_b,
        'ng_a': ng_a,
        'ng_b': ng_b,
        'avg_ng': (ng_a + ng_b) / total if total else 0,
        'avg_a': ng_a / total if total else 0,
        'avg_b': ng_b / total if total else 0,
        'utilization': util,
        'ct_avg': ct_avg,
        'ct_now': ct_now,
        'ct_now_mean': ct_now_mean,
        'point_distribution': point_distribution,
        'exact_point_distribution': exact_distribution,
        'ai': None,
    })


def fmt_num(x):
    return f'{x:.2f}'.rstrip('0').rstrip('.') if x else '0'


# =====================================================================
#  AI 缺陷檔匯入（需求 6）
# =====================================================================
def find_summary_csvs(folder):
    """遞迴搜尋資料夾（含所有子資料夾）內的 CSV，排除檔名含 result 的檔案（不分大小寫）。
    回傳 (要處理的檔案清單, 因檔名含 result 而排除的數量)。"""
    folder = Path(folder)
    keep, excluded = [], 0
    for path in folder.rglob('*.csv'):
        if not path.is_file():
            continue
        if 'result' in path.name.lower():
            excluded += 1
            continue
        keep.append(path)
    keep.sort(key=lambda p: [int(t) if t.isdigit() else t.lower()
                             for t in re.split(r'(\d+)', str(p.relative_to(folder)))])
    return keep, excluded


def find_ai_files(folder, patterns='*.ai;AI*.csv', recursive=True):
    """在資料夾內依檔名樣式（以 ; 或 , 分隔，可用 * ?）找 AI 缺陷檔。"""
    folder = Path(folder)
    pats = [p.strip() for p in re.split(r'[;,]', patterns or '') if p.strip()] or ['*.ai']
    found = {}
    for pat in pats:
        it = folder.rglob(pat) if recursive else folder.glob(pat)
        for path in it:
            if path.is_file():
                found[str(path).lower()] = path
    return sorted(found.values(), key=lambda p: [int(t) if t.isdigit() else t.lower()
                                                 for t in re.split(r'(\d+)', p.name)])


def parse_ai_files(paths):
    """讀取 AI 缺陷檔。Step_Code 後 4 碼＝Strip ID；AVI_Bin_Name 例如 DefectCode_Metal_Discolor。"""
    defects, bad, used = [], [], 0
    for path in paths:
        try:
            rows = list(csv.reader(io.StringIO(decode_bytes(Path(path).read_bytes()))))
        except OSError as exc:
            bad.append((Path(path).name, str(exc)))
            continue
        h = next((i for i, r in enumerate(rows) if r and r[0].strip() == 'Series_No'), None)
        if h is None:
            bad.append((Path(path).name, '找不到欄位列 Series_No'))
            continue
        col = {name.strip(): i for i, name in enumerate(rows[h])}
        need = ['Step_Code', 'Side', 'AVI_Bin_Name']
        if any(n not in col for n in need):
            bad.append((Path(path).name, '缺少欄位 ' + '/'.join(n for n in need if n not in col)))
            continue

        def cell(r, name):
            i = col.get(name)
            return r[i].strip() if i is not None and i < len(r) else ''
        used += 1
        for r in rows[h + 1:]:
            if not r or not r[0].strip().isdigit():
                continue
            step_code = cell(r, 'Step_Code')
            m = re.search(r'(\d{4})\s*$', step_code)
            if not m:
                continue
            name = cell(r, 'AVI_Bin_Name')
            name = re.sub(r'^DefectCode_', '', name)
            region, _, dtype = name.partition('_')
            defects.append({
                'file': Path(path).name,
                'strip_id': m.group(1),
                'step_code': step_code,
                'side': cell(r, 'Side'),
                'region': region or '未知',
                'type': dtype or '未知',
                'label': f'{region or "未知"}/{dtype or "未知"}',
                'pos_x': cell(r, 'Step_Pos_X'),
                'pos_y': cell(r, 'Step_Pos_Y'),
            })
    return {'defects': defects, 'bad_files': bad, 'file_count': used}


def build_ai_stats(stats, ai):
    """與主報表以 Strip ID 比對，產出缺陷類型分布（前五 + 其他）與主要缺陷位置/類型。"""
    summary_ids = {}
    for code, rec in stats['final_ng'].items():
        if rec['strip_id'] != UNREADABLE_ID:
            summary_ids.setdefault(rec['strip_id'], []).append(rec)
    readable = [r for r in stats['first_rows'] if r['strip_id'] != UNREADABLE_ID]
    all_ids = {r['strip_id'] for r in readable}
    dup_ids = len(readable) - len(all_ids)

    matched = [d for d in ai['defects'] if d['strip_id'] in all_ids]
    unmatched_ids = {d['strip_id'] for d in ai['defects']} - all_ids
    ai_ids = {d['strip_id'] for d in matched}
    label_cnt = Counter(d['label'] for d in matched)
    region_cnt = Counter(d['region'] for d in matched)
    side_cnt = Counter(d['side'] for d in matched)
    total = sum(label_cnt.values())

    ranked = label_cnt.most_common()
    top5 = ranked[:5]
    other = sum(c for _, c in ranked[5:])
    type_rows = [(lab, c) for lab, c in top5]
    if other:
        type_rows.append(('其他', other))
    top_label, top_count = (ranked[0] if ranked else ('—', 0))
    top_region, _, top_type = top_label.partition('/')

    # 每條比對：主報表 NG 點數 vs AI 缺陷筆數
    per_strip = Counter(d['strip_id'] for d in matched)
    compare = []
    for sid in sorted(all_ids):
        recs = summary_ids.get(sid, [])
        pts = sum(r['points'] for r in recs)
        compare.append((sid, pts, per_strip.get(sid, 0)))
    grid = Counter((d['side'], d['pos_x'], d['pos_y']) for d in matched if d['pos_x'] and d['pos_y'])
    no_pos = sum(1 for d in matched if not (d['pos_x'] and d['pos_y']))

    stats['ai'] = {
        'file_count': ai['file_count'],
        'bad_files': ai['bad_files'],
        'defect_total': len(ai['defects']),
        'matched_total': total,
        'matched_strips': len(ai_ids),
        'summary_strips_without_ai': len(all_ids - ai_ids),
        'ai_ids_not_in_summary': len(unmatched_ids),
        'dup_ids': dup_ids,
        'unreadable_strips': stats['unreadable_strips'],
        'label_counter': label_cnt,
        'ranked': ranked,
        'type_rows': type_rows,
        'region_counter': region_cnt,
        'side_counter': side_cnt,
        'top_label': top_label,
        'top_region': top_region,
        'top_type': top_type,
        'top_count': top_count,
        'top_pct': top_count / total if total else 0,
        'compare': compare,
        'grid': grid,
        'no_pos': no_pos,
        'mismatch_strips': sum(1 for _, p, a in compare if a and p != a),
    }


# =====================================================================
#  圖表 / PDF
# =====================================================================
NAVY, TEAL, PALE, ORANGE = '#15324B', '#1B9AAA', '#B8DCE3', '#E99B45'
TYPE_COLORS = ['#15324B', '#1B9AAA', '#E99B45', '#7AA7FF', '#63B38F', '#B8C4CE']


def _style_axes(ax):
    ax.grid(axis='y', color='#DCE4EA', linewidth=0.8)
    ax.set_axisbelow(True)
    ax.spines[['top', 'right', 'left']].set_visible(False)
    ax.spines['bottom'].set_color('#C5D0D8')
    ax.tick_params(axis='both', labelsize=8, colors='#526575')


def make_chart(stats, path=None):
    path = Path(path) if path else CHART_PATH
    stats['chart_path'] = str(path)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), dpi=180,
                             gridspec_kw={'width_ratios': [1.2, 0.8, 1.5]})
    fig.patch.set_facecolor('#ffffff')

    ax = axes[0]
    labels = [d['區間'] for d in stats['point_distribution']]
    counts = [d['條數'] for d in stats['point_distribution']]
    bars = ax.bar(labels, counts, color=TEAL, width=0.68)
    ax.set_title('每條 NG 缺點數分布（NF 排除）', loc='left', fontsize=12, color=NAVY, pad=12)
    ax.set_xlabel('單條 NG 缺點點數區間', fontsize=9)
    ax.set_ylabel('條數', fontsize=9)
    _style_axes(ax)
    ax.bar_label(bars, padding=3, fontsize=8, color=NAVY)
    ax.set_ylim(0, max(counts or [1]) * 1.22 or 1)

    ax = axes[1]
    vals = [stats['avg_a'], stats['avg_b']]
    bars = ax.bar(['正面 A', '背面 B'], vals, color=[NAVY, TEAL], width=0.56)
    ax.set_title('正 / 背面 條平均點數', loc='left', fontsize=12, color=NAVY, pad=12)
    ax.set_ylabel('點 / 條', fontsize=9)
    _style_axes(ax)
    ax.bar_label(bars, labels=[f'{v:.2f}' for v in vals], padding=4, fontsize=9, color=NAVY)
    ax.set_ylim(0, max(vals or [1]) * 1.22 or 1)
    ax.text(0.5, -0.20, f'總點數  A {stats["ng_a"]:,}｜B {stats["ng_b"]:,}　÷ {stats["core_total"]:,} 條',
            transform=ax.transAxes, ha='center', va='top', fontsize=8, color='#526575')

    ax = axes[2]
    ai = stats.get('ai')
    if ai and ai['type_rows']:
        rows = ai['type_rows'][::-1]
        names = [n for n, _ in rows]
        cnts = [c for _, c in rows]
        tot = sum(cnts)
        colors = [TYPE_COLORS[min(len(rows) - 1 - i, 5)] if n != '其他' else TYPE_COLORS[5]
                  for i, (n, _) in enumerate(rows)]
        bars = ax.barh(names, cnts, color=colors, height=0.62)
        ax.set_title('主要缺陷類型分布（位置/類型，前五＋其他）', loc='left', fontsize=12, color=NAVY, pad=12)
        ax.grid(axis='x', color='#DCE4EA', linewidth=0.8)
        ax.set_axisbelow(True)
        ax.spines[['top', 'right', 'bottom']].set_visible(False)
        ax.spines['left'].set_color('#C5D0D8')
        ax.tick_params(axis='both', labelsize=9, colors='#526575')
        ax.bar_label(bars, labels=[f'{c:,}（{c / tot:.1%}）' for c in cnts], padding=4,
                     fontsize=8.5, color=NAVY)
        ax.set_xlim(0, max(cnts) * 1.32)
        ax.set_xlabel('缺陷筆數', fontsize=9)
    else:
        ax.axis('off')
        ax.set_title('主要缺陷類型分布', loc='left', fontsize=12, color=NAVY, pad=12)
        ax.text(0.5, 0.5, '尚未匯入 AI 缺陷檔\n（在程式中選擇 AI 檔資料夾與檔名樣式）',
                ha='center', va='center', fontsize=10, color='#82909B', transform=ax.transAxes)

    fig.subplots_adjust(left=0.045, right=0.985, top=0.83, bottom=0.2, wspace=0.42)
    fig.savefig(path, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def _time_range_text(stats):
    s, e = stats['start'], stats['end']
    if s.date() == e.date():
        return f'{s:%Y-%m-%d %H:%M:%S} ～ {e:%H:%M:%S}'
    return f'{s:%Y-%m-%d %H:%M:%S} ～ {e:%Y-%m-%d %H:%M:%S}'


def make_pdf(stats):
    from matplotlib.patches import FancyBboxPatch
    fig = plt.figure(figsize=(11.69, 8.27), dpi=180, facecolor='#F4F7FA')
    b0 = stats['batches'][0]
    fig.text(0.055, 0.955, REPORT_TITLE, fontsize=22, fontweight='bold', color=NAVY, va='top')
    fig.text(0.056, 0.913,
             f'料號 {b0["product"]}　｜　批號 {b0["lot"]}　｜　日期 {stats["start"]:%Y-%m-%d}　｜　'
             f'機台 {b0["machine"]}　｜　作業員 {b0["operator"]}',
             fontsize=9.5, color='#526575', va='top')
    fig.text(0.944, 0.955, f'來源：{len(stats["batches"])} 個 CSV 檢驗批次', ha='right',
             fontsize=8.5, color='#526575', va='top')
    fig.text(0.056, 0.882, _time_range_text(stats), fontsize=8.5, color='#526575', va='top')

    ai = stats.get('ai')
    if ai and ai['matched_total']:
        c6 = (f'{ai["top_region"]} / {ai["top_type"]}',
              f'{ai["top_count"]:,} 筆，占 AI 缺陷 {ai["top_pct"]:.1%}')
    else:
        c6 = ('未匯入 AI 檔', '請於程式選擇 AI 缺陷檔資料夾')
    cards = [
        ('首檢 / 複檢 / 總條數',
         f'{stats["core_first"]:,} / {stats["core_recheck"]:,} / {stats["core_total"]:,}',
         '首檢＝僅檢一次且非 NF；複檢＝其餘（含 NF）', False),
        ('總缺點數 / 條平均缺點數（僅 NG）',
         f'{stats["ng_points"]:,} 點 / {stats["avg_ng"]:.2f}',
         f'NG 點數 ÷ 總條數 {stats["core_total"]:,}（NF 不計）', True),
        ('正面條平均 / 背面條平均 點數',
         f'A {stats["avg_a"]:.2f} / B {stats["avg_b"]:.2f}',
         f'A {stats["ng_a"]:,} 點／B {stats["ng_b"]:,} 點 ÷ 總條數', False),
        ('檢驗起訖 / 實際檢驗時間（稼動率）',
         f'{fmt_hms(stats["active_seconds"])}（{stats["utilization"]:.1%}）',
         f'{stats["start"]:%H:%M:%S}～{stats["end"]:%H:%M:%S}｜總經過 {fmt_hms(stats["wall_seconds"])}', False),
        ('CTAvgTime / CTNowTime',
         f'{fmt_num(stats["ct_avg"])} / {fmt_num(stats["ct_now"])}',
         '單位 UPH（條/時）；Avg 依條數加權、Now 取最後批次', False),
        ('最主要缺陷 位置 / 類型', c6[0], c6[1], False),
    ]
    positions = [(0.055, 0.748), (0.365, 0.748), (0.675, 0.748),
                 (0.055, 0.626), (0.365, 0.626), (0.675, 0.626)]
    for (title, value, note, hot), (x, y) in zip(cards, positions):
        ax = fig.add_axes([x, y, 0.27, 0.105])
        ax.set_axis_off()
        ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle='round,pad=0.015,rounding_size=0.04',
                                    transform=ax.transAxes,
                                    facecolor='#E8F8FA' if hot else 'white',
                                    edgecolor=TEAL if hot else '#D9E2E8',
                                    linewidth=1.8 if hot else 0.8))
        ax.text(0.06, 0.79, title, transform=ax.transAxes, fontsize=8, color='#526575', va='center')
        ax.text(0.06, 0.48, value, transform=ax.transAxes, fontsize=15 if hot else 13.5,
                fontweight='bold', color=NAVY, va='center')
        ax.text(0.06, 0.16, note, transform=ax.transAxes, fontsize=7.2, color='#526575', va='center')

    img = plt.imread(stats.get('chart_path') or CHART_PATH)
    chart_ax = fig.add_axes([0.052, 0.27, 0.896, 0.33])
    chart_ax.imshow(img)
    chart_ax.axis('off')

    note1 = ('計算口徑：以「批號＋4 位 Strip ID」為唯一條；NG 缺點數每條取最後一筆 NG 紀錄，NF 一律不計；'
             f'條平均缺點數 ＝ NG 總點數 ÷ 總條數。稼動率 ＝ 批次內檢驗時間加總 ÷ 開始至結束經過時間。'
             f'（NF 條 {stats["core_nf_strips"]} 條；總檢驗條次 {stats["event_count"]}，'
             f'重檢紀錄 {stats["reinspection_rows"]} 筆）')
    if stats['unreadable_strips']:
        note1 += (f'　※ 2D Code 讀取失敗（FAILED）{stats["unreadable_strips"]} 條，無 Strip ID，'
                  '每筆視為獨立的條，且不參與 AI 檔比對。')
    if ai:
        note2 = (f'AI 缺陷比對：讀入 {ai["file_count"]} 個 AI 檔、{ai["defect_total"]:,} 筆缺陷；'
                 f'以 Step_Code 後 4 碼對應 Strip ID，比對成功 {ai["matched_strips"]} 條 / {ai["matched_total"]:,} 筆；'
                 f'主報表有、AI 檔缺 {ai["summary_strips_without_ai"]} 條；AI 檔有、主報表無 {ai["ai_ids_not_in_summary"]} 條；'
                 f'兩邊點數不一致 {ai["mismatch_strips"]} 條（AI 檔中無位置資料的缺陷 {ai["no_pos"]} 筆，主報表點數不計入，多為此因）。')
    else:
        note2 = '未匯入 AI 缺陷檔，因此缺陷位置/類型欄位無資料。'
    fig.text(0.057, 0.205, note1, fontsize=7.4, color='#394B59', va='top', wrap=True)
    fig.text(0.057, 0.140, note2, fontsize=7.2, color='#526575', va='top', wrap=True)
    fig.text(0.945, 0.035, f'報告日期：{datetime.now():%Y-%m-%d}', ha='right', fontsize=7, color='#82909B')
    fig.savefig(PDF_PATH, format='pdf', bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close(fig)


def style_header(ws, row, start_col, end_col):
    fill = PatternFill('solid', fgColor='15324B')
    for col in range(start_col, end_col + 1):
        cell = ws.cell(row, col)
        cell.fill = fill
        cell.font = Font(name='Aptos', size=10, bold=True, color='FFFFFF')
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)


def add_table(ws, name, ref):
    tab = Table(displayName=name, ref=ref)
    tab.tableStyleInfo = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False,
                                        showLastColumn=False, showRowStripes=True, showColumnStripes=False)
    ws.add_table(tab)


def _font(size=9, bold=False, color='1F2D3D', italic=False):
    return Font(name='Microsoft JhengHei', size=size, bold=bold, color=color, italic=italic)


def make_workbook(stats):
    wb = Workbook()
    ws = wb.active
    ws.title = '生產報告'
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = 'A5'
    meta = stats['batches'][0]
    ai = stats.get('ai')
    ws.merge_cells('A1:C1')
    ws['A1'] = REPORT_TITLE
    ws['A1'].fill = PatternFill('solid', fgColor='15324B')
    ws['A1'].font = Font(name='Microsoft JhengHei', size=20, bold=True, color='FFFFFF')
    ws['A1'].alignment = Alignment(vertical='center')
    ws.row_dimensions[1].height = 34
    ws.merge_cells('A2:C2')
    ws['A2'] = (f'料號 {meta["product"]}　｜　批號 {meta["lot"]}　｜　日期 {stats["start"]:%Y-%m-%d}　｜　'
                f'機台 {meta["machine"]}　｜　作業員 {meta["operator"]}')
    ws['A2'].font = _font(10, color='526575')
    ws['A2'].alignment = Alignment(vertical='center')
    ws.row_dimensions[2].height = 24
    ws.merge_cells('A3:C3')
    ws['A3'] = '以「批號＋4 位 Strip ID」為唯一條；缺點數只計 NG（每條取最後一筆 NG），NF 不計。'
    ws['A3'].font = _font(9, color='526575', italic=True)
    ws['A3'].alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[3].height = 23

    for c, value in enumerate(['指標', '數值', '口徑／備註'], 1):
        ws.cell(5, c, value)
    style_header(ws, 5, 1, 3)
    if ai and ai['matched_total']:
        top_val = f'{ai["top_region"]} / {ai["top_type"]}'
        top_note = f'{ai["top_count"]:,} 筆，占 AI 缺陷 {ai["top_pct"]:.1%}（AVI_Bin_Name：位置_類型）'
    else:
        top_val, top_note = '未匯入 AI 檔', '請於程式選擇 AI 缺陷檔資料夾與檔名樣式'
    # (標籤, 值, 備註, 是否重點)
    metrics = [
        ('1. 首檢條數', stats['core_first'], '只檢驗一次且非 NF 的條', False),
        ('1. 複檢條數', stats['core_recheck'],
         f'有 NF 或檢驗多次的條（其中含 NF {stats["core_nf_strips"]} 條）', False),
        ('1. 總條數', stats['core_total'], '唯一條數（首檢＋複檢）', False),
        ('2. 總缺點數（僅 NG）', stats['ng_points'],
         f'正面 A {stats["ng_a"]:,} + 背面 B {stats["ng_b"]:,}；NF 不計', True),
        ('2. 條平均缺點數（僅 NG）', round(stats['avg_ng'], 2),
         f'NG 總點數 {stats["ng_points"]:,} ÷ 總條數 {stats["core_total"]:,}', True),
        ('3. 正面條平均點數 (A)', round(stats['avg_a'], 2), f'{stats["ng_a"]:,} ÷ {stats["core_total"]:,} 條', False),
        ('3. 背面條平均點數 (B)', round(stats['avg_b'], 2), f'{stats["ng_b"]:,} ÷ {stats["core_total"]:,} 條', False),
        ('4. 檢驗開始', stats['start'].strftime('%Y-%m-%d %H:%M:%S'), '最早批次開始時間', False),
        ('4. 檢驗結束', stats['end'].strftime('%Y-%m-%d %H:%M:%S'), '最晚批次結束時間', False),
        ('4. 實際檢驗時間', fmt_hms(stats['active_seconds']), '各批次（結束－開始）加總', False),
        ('4. 稼動率', f'{stats["utilization"]:.1%}',
         f'實際檢驗時間 ÷ 總經過時間 {fmt_hms(stats["wall_seconds"])}；批次間隔 {fmt_hms(stats["downtime_seconds"])}', False),
        ('5. CTAvgTime（UPH）', fmt_num(stats['ct_avg']), '各批次 AutoRunCTAvgTime（條/時），依條數加權平均', False),
        ('5. CTNowTime（UPH）', fmt_num(stats['ct_now']),
         f'最後一個批次 AutoRunCTNowTime（各批平均 {fmt_num(stats["ct_now_mean"])}）', False),
        ('6. 最主要缺陷 位置/類型', top_val, top_note, False),
        ('總檢驗條次（含重檢）', stats['event_count'], f'重檢紀錄 {stats["reinspection_rows"]} 筆', False),
    ]
    for r_idx, (label, value, note, hot) in enumerate(metrics, 6):
        for c_idx, value_ in enumerate((label, value, note), 1):
            cell = ws.cell(r_idx, c_idx, value_)
            cell.font = _font(10 if hot else 9, bold=hot or c_idx == 2, color='0E6670' if hot else '1F2D3D')
            cell.alignment = Alignment(vertical='center', wrap_text=True, horizontal='left')
            if hot:
                cell.fill = PatternFill('solid', fgColor='DDF3F5')
            elif r_idx % 2 == 0:
                cell.fill = PatternFill('solid', fgColor='F1F5F8')
        ws.row_dimensions[r_idx].height = 27 if len(note) > 50 else 23

    img = XLImage(str(stats.get('chart_path') or CHART_PATH))
    img.width = 1050
    img.height = int(1050 * 4.6 / 15)
    ws.add_image(img, 'E5')
    ws.column_dimensions['A'].width = 30
    ws.column_dimensions['B'].width = 24
    ws.column_dimensions['C'].width = 70
    for col in range(4, 18):
        ws.column_dimensions[get_column_letter(col)].width = 12

    # 主要缺陷類型分布（前五＋其他）
    top_row = 24
    ws.cell(top_row, 5, '主要缺陷類型分布（位置/類型，前五項＋其他）')
    ws.merge_cells(start_row=top_row, start_column=5, end_row=top_row, end_column=8)
    ws.cell(top_row, 5).font = _font(10, True, '15324B')
    for col, value in enumerate(['排名', '位置/類型', '缺陷筆數', '占比'], 5):
        ws.cell(top_row + 1, col, value)
    style_header(ws, top_row + 1, 5, 8)
    rows = ai['type_rows'] if ai else []
    tot = sum(c for _, c in rows)
    for i, (name, cnt) in enumerate(rows, 1):
        r = top_row + 1 + i
        ws.cell(r, 5, i if name != '其他' else '—')
        ws.cell(r, 6, name)
        ws.cell(r, 7, cnt)
        ws.cell(r, 8, cnt / tot if tot else 0).number_format = '0.0%'
        for col in range(5, 9):
            ws.cell(r, col).font = _font(9)
            ws.cell(r, col).alignment = Alignment(horizontal='center', vertical='center')
            if r % 2 == 0:
                ws.cell(r, col).fill = PatternFill('solid', fgColor='F1F5F8')
    if rows:
        add_table(ws, 'TopDefectTypes', f'E{top_row + 1}:H{top_row + 1 + len(rows)}')
    else:
        ws.cell(top_row + 2, 5, '尚未匯入 AI 缺陷檔').font = _font(9, color='82909B')

    note_start = 33
    notes = ['報表口徑與限制',
             '1. 首檢＝只檢驗一次且非 NF；複檢＝其餘（含 NF 後再檢、重複檢驗）；首檢＋複檢＝總條數。',
             '2. 缺點數只計 NG：每條取最後一筆 NG 紀錄的點數；NF 紀錄不計。條平均缺點數＝NG 總點數 ÷ 總條數（含無 NG 紀錄的條）。',
             '3. 稼動率＝批次內檢驗時間加總 ÷（最晚結束－最早開始）；批次間隔含午休等非檢驗時間。',
             '4. CTAvgTime、CTNowTime 取自摘要 CSV 的 AutoRunCTAvgTime / AutoRunCTNowTime，原檔單位為 UPH（條/時）。',
             '5. 缺陷位置/類型來自 AI 缺陷檔 AVI_Bin_Name（DefectCode_位置_類型），以 Step_Code 後 4 碼對應 Strip ID。']
    if ai:
        notes.append(f'6. AI 比對：{ai["file_count"]} 個檔、{ai["defect_total"]:,} 筆缺陷；比對成功 {ai["matched_strips"]} 條；'
                     f'主報表有而 AI 無 {ai["summary_strips_without_ai"]} 條、AI 有而主報表無 {ai["ai_ids_not_in_summary"]} 條；'
                     f'點數不一致 {ai["mismatch_strips"]} 條（AI 檔無位置資料的缺陷 {ai["no_pos"]} 筆不計入主報表點數；詳見「AI缺陷比對」）。')
    if stats['unreadable_strips']:
        notes.append(f'7. 2D Code 讀取失敗（FAILED）共 {stats["unreadable_strips"]} 條，無法取得 Strip ID：每筆視為獨立的條，不參與 AI 檔比對。')
    ws.merge_cells(start_row=note_start, start_column=1, end_row=note_start, end_column=3)
    ws.cell(note_start, 1, notes[0]).font = _font(10, True, '15324B')
    for i, text in enumerate(notes[1:], note_start + 1):
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=3)
        cell = ws.cell(i, 1, text)
        cell.font = _font(9, color='526575')
        cell.alignment = Alignment(wrap_text=True, vertical='top')
        ws.row_dimensions[i].height = 30 if len(text) > 60 else 24
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.print_area = f'A1:Q{note_start + len(notes)}'

    # Batch-level table.
    wb_batch = wb.create_sheet('批次明細')
    wb_batch.sheet_view.showGridLines = False
    wb_batch.append(['來源批次', '開始時間', '結束時間', '批次內時間', '與前批間隔',
                     '本批檢驗條數', '本批檢驗單位數', '摘要NG條數', '摘要NF條數', '摘要OK條數',
                     '首檢唯一條數', '其中首檢NF', '重檢紀錄列', '設備平均UPH', '設備即時UPH',
                     '機台', '作業員'])
    for b in stats['batches']:
        prev_gap = b['gap_before_seconds']
        wb_batch.append([
            b['file'], b['start'], b['end'], fmt_hms(b['duration_seconds']), fmt_hms(prev_gap),
            b['strip_count'], b['unit_count'], b['strip_ng'], b['strip_nf'], b['strip_ok'],
            b['first_pass_unique'], b['first_pass_nf'], b['reinspection_rows'],
            b['reported_uph'], b['current_uph'], b['machine'], b['operator']
        ])
    style_header(wb_batch, 1, 1, wb_batch.max_column)
    wb_batch.freeze_panes = 'A2'
    wb_batch.auto_filter.ref = f'A1:Q{wb_batch.max_row}'
    widths = [27, 21, 21, 18, 18, 14, 16, 14, 14, 14, 14, 12, 14, 16, 16, 12, 12]
    for i, width in enumerate(widths, 1):
        wb_batch.column_dimensions[get_column_letter(i)].width = width
    for row in wb_batch.iter_rows(min_row=2, min_col=2, max_col=3):
        for c in row:
            c.number_format = 'yyyy-mm-dd hh:mm:ss'
    add_table(wb_batch, 'BatchDetails', f'A1:Q{wb_batch.max_row}')

    # Unique strip first-pass view plus latest results.
    wb_first = wb.create_sheet('首檢明細')
    first_headers = ['首檢來源CSV', '首檢開始時間', 'Strip ID', '首檢判定', '首檢Yield%',
                     'A面缺陷單位', 'B面缺陷單位', 'A面總缺點', 'B面總缺點', '首檢總點數',
                     'A面邊緣點', 'B面邊緣點', '一般區推算點數', '首檢NF是否排除',
                     '出現次數', '最新來源CSV', '最新檢驗時間', '最新判定', '最新總點數']
    wb_first.append(first_headers)
    for r in stats['first_rows']:
        latest = next(x for x in stats['latest_rows'] if x['code'] == r['code'])
        wb_first.append([
            r['file'], r['start'], r['strip_id'], r['status'], r['yield_pct'],
            r['unit_a'], r['unit_b'], r['defect_a'], r['defect_b'], r['points'],
            r['border_a'], r['border_b'], r['general_points'], '是' if r['status'] == 'NF' else '否',
            stats['occurrence_counts'][r['code']], latest['file'], latest['start'], latest['status'], latest['points']
        ])
    style_header(wb_first, 1, 1, wb_first.max_column)
    wb_first.freeze_panes = 'A2'
    widths = [27, 21, 10, 12, 12, 14, 14, 12, 12, 12, 12, 12, 15, 15, 12, 27, 21, 12, 12]
    for i, width in enumerate(widths, 1):
        wb_first.column_dimensions[get_column_letter(i)].width = width
    for row in wb_first.iter_rows(min_row=2, min_col=2, max_col=2): row[0].number_format = 'yyyy-mm-dd hh:mm:ss'
    for row in wb_first.iter_rows(min_row=2, min_col=18, max_col=18): row[0].number_format = 'yyyy-mm-dd hh:mm:ss'
    add_table(wb_first, 'FirstPassStrips', f'A1:S{wb_first.max_row}')

    # All source observations, including retests.
    wb_raw = wb.create_sheet('全部檢驗紀錄')
    raw_headers = ['檢驗開始', '檢驗結束', 'Strip ID', '判定', 'Yield%',
                   'A面缺陷單位', 'B面缺陷單位', 'A面總缺點', 'B面總缺點', '總點數',
                   'A面邊緣點', 'B面邊緣點', '一般區推算點數', '首檢記錄', '最新記錄',
                   '該Strip ID檢驗次序', '該Strip ID總出現次數', '備註']
    wb_raw.append(raw_headers)
    for r in stats['observations']:
        wb_raw.append([
            r['start'], r['end'], r['strip_id'], r['status'], r['yield_pct'],
            r['unit_a'], r['unit_b'], r['defect_a'], r['defect_b'], r['points'],
            r['border_a'], r['border_b'], r['general_points'], '是' if r['is_first'] else '否',
            '是' if r['is_latest'] else '否', r['occurrence_no'], r['occurrence_count'], r['remark']
        ])
    style_header(wb_raw, 1, 1, wb_raw.max_column)
    wb_raw.freeze_panes = 'A2'
    widths = [21, 21, 10, 10, 10, 14, 14, 12, 12, 12, 12, 12, 15, 11, 11, 13, 14, 35]
    for i, width in enumerate(widths, 1):
        wb_raw.column_dimensions[get_column_letter(i)].width = width
    for row in wb_raw.iter_rows(min_row=2, min_col=1, max_col=2):
        for c in row: c.number_format = 'yyyy-mm-dd hh:mm:ss'
    add_table(wb_raw, 'AllInspectionRecords', f'A1:R{wb_raw.max_row}')

    # 每條 NG 缺點點數分布
    wb_dist = wb.create_sheet('缺點點數分布')
    wb_dist.sheet_view.showGridLines = False
    wb_dist.append(['缺點點數', '條數', '占NG條數比例'])
    for item in stats['exact_point_distribution']:
        wb_dist.append([item['缺點點數'], item['條數'], item['占NG條數比例']])
    style_header(wb_dist, 1, 1, 3)
    wb_dist.freeze_panes = 'A2'
    wb_dist.column_dimensions['A'].width = 16
    wb_dist.column_dimensions['B'].width = 12
    wb_dist.column_dimensions['C'].width = 18
    for row in range(2, wb_dist.max_row + 1):
        wb_dist.cell(row, 3).number_format = '0.0%'
    if wb_dist.max_row > 1:
        add_table(wb_dist, 'PointDistribution', f'A1:C{wb_dist.max_row}')

    if ai:
        # 缺陷類型全表
        w = wb.create_sheet('缺陷類型分布')
        w.sheet_view.showGridLines = False
        w.append(['排名', '位置', '類型', '位置/類型', '缺陷筆數', '占比'])
        total = ai['matched_total'] or 1
        for i, (label, cnt) in enumerate(ai['ranked'], 1):
            region, _, dtype = label.partition('/')
            w.append([i, region, dtype, label, cnt, cnt / total])
        style_header(w, 1, 1, 6)
        w.freeze_panes = 'A2'
        for i, width in enumerate([8, 12, 20, 28, 12, 10], 1):
            w.column_dimensions[get_column_letter(i)].width = width
        for row in range(2, w.max_row + 1):
            w.cell(row, 6).number_format = '0.0%'
        if w.max_row > 1:
            add_table(w, 'DefectTypes', f'A1:F{w.max_row}')
        base = w.max_row + 3
        w.cell(base, 1, '位置合計').font = _font(10, True, '15324B')
        for j, (region, cnt) in enumerate(ai['region_counter'].most_common(), base + 1):
            w.cell(j, 2, region)
            w.cell(j, 5, cnt)
            w.cell(j, 6, cnt / total).number_format = '0.0%'
        base = w.max_row + 3
        w.cell(base, 1, '面別合計（AI 檔 Side 欄）').font = _font(10, True, '15324B')
        for j, (side, cnt) in enumerate(ai['side_counter'].most_common(), base + 1):
            w.cell(j, 2, side)
            w.cell(j, 5, cnt)
            w.cell(j, 6, cnt / total).number_format = '0.0%'

        # 與主報表逐條比對
        w = wb.create_sheet('AI缺陷比對')
        w.sheet_view.showGridLines = False
        w.append(['Strip ID', '主報表NG點數', 'AI缺陷筆數', '差異(AI−主報表)', '狀態'])
        for sid, pts, cnt in ai['compare']:
            state = '一致' if cnt == pts and cnt else ('AI檔缺少' if not cnt else '不一致')
            w.append([sid, pts, cnt, cnt - pts, state])
        style_header(w, 1, 1, 5)
        w.freeze_panes = 'A2'
        for i, width in enumerate([12, 16, 14, 18, 12], 1):
            w.column_dimensions[get_column_letter(i)].width = width
        w.auto_filter.ref = f'A1:E{w.max_row}'
        for row in w.iter_rows(min_row=2, min_col=1, max_col=1):
            row[0].number_format = '@'

        # 缺陷位置（單元格位置）
        w = wb.create_sheet('缺陷位置')
        w.sheet_view.showGridLines = False
        xs = sorted({int(x) for _, x, _ in ai['grid'] if x.isdigit()})
        ys = sorted({int(y) for _, _, y in ai['grid'] if y.isdigit()})
        r0 = 1
        for side in sorted({s for s, _, _ in ai['grid']}):
            w.cell(r0, 1, f'Side {side}（Step_Pos_X 欄 × Step_Pos_Y 列）').font = _font(10, True, '15324B')
            w.cell(r0 + 1, 1, 'Y \\ X')
            for j, x in enumerate(xs, 2):
                w.cell(r0 + 1, j, x)
            style_header(w, r0 + 1, 1, 1 + len(xs))
            for i, y in enumerate(ys, r0 + 2):
                w.cell(i, 1, y).font = _font(9, True)
                for j, x in enumerate(xs, 2):
                    w.cell(i, j, ai['grid'].get((side, str(x), str(y)), 0)).font = _font(9)
            from openpyxl.formatting.rule import ColorScaleRule
            rng = f'B{r0 + 2}:{get_column_letter(1 + len(xs))}{r0 + 1 + len(ys)}'
            w.conditional_formatting.add(rng, ColorScaleRule(start_type='min', start_color='FFFFFF',
                                                             end_type='max', end_color='E99B45'))
            r0 += len(ys) + 4
        w.cell(r0, 1, f'無位置資料的缺陷：{ai["no_pos"]:,} 筆').font = _font(9, color='526575')
        w.column_dimensions['A'].width = 14

    wb.save(XLSX_PATH)


def generate_outputs(stats, outputs=('pdf', 'xlsx', 'png'), progress=None):
    """依勾選的 outputs（pdf / xlsx / png）輸出；回傳實際輸出的檔案路徑清單。"""
    import tempfile
    outputs = set(outputs)
    if not outputs:
        raise ValueError('請至少選擇一種輸出檔案')
    tick = progress or (lambda v: None)
    tmp_dir = None
    produced = []
    try:
        if 'png' in outputs:
            chart_path = CHART_PATH
        else:
            tmp_dir = tempfile.mkdtemp(prefix='report_chart_')
            chart_path = Path(tmp_dir) / 'chart.png'
        make_chart(stats, chart_path)
        tick(70)
        if 'png' in outputs:
            produced.append(CHART_PATH)
        if 'pdf' in outputs:
            make_pdf(stats)
            produced.insert(0, PDF_PATH)
        tick(85)
        if 'xlsx' in outputs:
            make_workbook(stats)
            produced.insert(1 if 'pdf' in outputs else 0, XLSX_PATH)
        tick(100)
    finally:
        if tmp_dir:
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)
    return produced


def main(ai_dir=None, ai_patterns='*.ai;AI*.csv', outputs=('pdf', 'xlsx', 'png')):
    batches, observations = parse_archive()
    stats = build_views(batches, observations)
    if ai_dir:
        files = find_ai_files(ai_dir, ai_patterns)
        if not files:
            raise ValueError(f'在 {ai_dir} 找不到符合「{ai_patterns}」的 AI 檔')
        build_ai_stats(stats, parse_ai_files(files))
    generate_outputs(stats, outputs)
    if 'xlsx' not in outputs:
        print('REPORTS_CREATED'); return stats

    check = load_workbook(XLSX_PATH, read_only=False, data_only=True)
    expected = {'生產報告', '批次明細', '首檢明細', '全部檢驗紀錄', '缺點點數分布'}
    if stats.get('ai'):
        expected |= {'缺陷類型分布', 'AI缺陷比對', '缺陷位置'}
    if set(check.sheetnames) != expected:
        raise ValueError(f'活頁簿工作表不符：{check.sheetnames}')
    if check['首檢明細'].max_row != stats['first_count'] + 1:
        raise ValueError('首檢明細筆數驗證失敗')
    if check['全部檢驗紀錄'].max_row != stats['event_count'] + 1:
        raise ValueError('全部檢驗紀錄筆數驗證失敗')
    print('REPORTS_CREATED')
    for k in ('core_first', 'core_recheck', 'core_total', 'ng_points', 'avg_ng', 'avg_a', 'avg_b',
              'utilization', 'ct_avg', 'ct_now'):
        print(k, stats[k])
    if stats.get('ai'):
        a = stats['ai']
        print('AI', a['matched_strips'], a['matched_total'], a['top_label'], a['mismatch_strips'])
    return stats


if __name__ == '__main__':
    main()
