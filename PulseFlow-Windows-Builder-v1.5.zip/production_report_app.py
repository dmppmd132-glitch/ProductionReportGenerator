#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PulseFlow：科技感生產報告桌面應用程式。"""
from __future__ import annotations

import queue
import tempfile
import threading
import traceback
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import build_226926131000_report as report


NAVY = '#071426'
PANEL = '#0D2038'
PANEL_2 = '#102B47'
CYAN = '#23D6D5'
CYAN_DARK = '#0E8E9B'
TEXT = '#EAF8FF'
MUTED = '#8EA9BC'
BORDER = '#1C4665'
GREEN = '#63E6BE'
RED = '#FF7186'


class ReportApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('PulseFlow')
        self.geometry(f'1000x{min(840, max(660, self.winfo_screenheight() - 90))}')
        self.minsize(880, 640)
        self.configure(bg=NAVY)
        self.input_dir = tk.StringVar()
        self.output_dir = tk.StringVar()
        self.ai_dir = tk.StringVar()
        self.ai_pattern = tk.StringVar(value='*.ai;AI*.csv')
        self.ai_recursive = tk.BooleanVar(value=True)
        self.out_pdf = tk.BooleanVar(value=True)
        self.out_xlsx = tk.BooleanVar(value=True)
        self.out_png = tk.BooleanVar(value=True)
        self.report_name = tk.StringVar(value='簡易生產報告')
        self.status = tk.StringVar(value='準備就緒｜請選擇含 CSV 的資料夾（含子資料夾）')
        self.progress_value = tk.DoubleVar(value=0)
        self.messages = queue.Queue()
        self.running = False
        self._setup_style()
        self._load_icon()
        self._build_ui()
        self.after(100, self._drain_messages)

    def _setup_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        style.configure('Tech.TFrame', background=NAVY)
        style.configure('Card.TFrame', background=PANEL)
        style.configure('Title.TLabel', background=NAVY, foreground=TEXT,
                        font=('Microsoft JhengHei UI', 24, 'bold'))
        style.configure('Subtitle.TLabel', background=NAVY, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 10))
        style.configure('CardTitle.TLabel', background=PANEL, foreground=TEXT,
                        font=('Microsoft JhengHei UI', 11, 'bold'))
        style.configure('CardText.TLabel', background=PANEL, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 9))
        style.configure('Field.TLabel', background=PANEL, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 9))
        style.configure('Tech.TEntry', fieldbackground='#091A2E', foreground=TEXT,
                        bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER,
                        insertcolor=CYAN, padding=8)
        style.configure('Accent.TButton', background=CYAN_DARK, foreground=TEXT,
                        bordercolor=CYAN, lightcolor=CYAN_DARK, darkcolor=CYAN_DARK,
                        font=('Microsoft JhengHei UI', 10, 'bold'), padding=(16, 9))
        style.map('Accent.TButton', background=[('active', '#16B8C0'), ('disabled', '#24445A')])
        style.configure('Ghost.TButton', background=PANEL_2, foreground=TEXT,
                        bordercolor=BORDER, lightcolor=PANEL_2, darkcolor=PANEL_2,
                        font=('Microsoft JhengHei UI', 9), padding=(12, 8))
        style.map('Ghost.TButton', background=[('active', '#1A4262')])
        style.configure('Tech.Horizontal.TProgressbar', troughcolor='#091A2E',
                        background=CYAN, bordercolor=BORDER, lightcolor=CYAN,
                        darkcolor=CYAN, thickness=8)
        style.configure('Status.TLabel', background=NAVY, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 9))

    def _load_icon(self):
        try:
            root = Path(getattr(__import__('sys'), '_MEIPASS', Path(__file__).parent))
            ico = root / 'app_icon.ico'
            if ico.exists():
                self.iconbitmap(str(ico))
            png = root / 'app_icon.png'
            if png.exists():
                self._icon_image = tk.PhotoImage(file=str(png))
                self.iconphoto(True, self._icon_image)
        except Exception:
            pass

    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        outer = ttk.Frame(self, style='Tech.TFrame', padding=(28, 22, 28, 18))
        outer.grid(row=0, column=0, rowspan=5, sticky='nsew')
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        header = ttk.Frame(outer, style='Tech.TFrame')
        header.grid(row=0, column=0, sticky='ew', pady=(0, 20))
        header.columnconfigure(1, weight=1)
        logo = tk.Canvas(header, width=58, height=58, bg=NAVY, highlightthickness=0)
        logo.grid(row=0, column=0, rowspan=2, padx=(0, 15))
        logo.create_oval(5, 5, 53, 53, fill='#0D314C', outline=CYAN, width=2)
        logo.create_rectangle(19, 14, 39, 44, fill='#EAF8FF', outline=CYAN, width=1)
        logo.create_rectangle(23, 34, 27, 40, fill=CYAN_DARK, outline='')
        logo.create_rectangle(29, 28, 33, 40, fill=CYAN, outline='')
        logo.create_rectangle(35, 22, 39, 40, fill='#63E6BE', outline='')
        ttk.Label(header, text='PulseFlow', style='Title.TLabel').grid(row=0, column=1, sticky='w')
        ttk.Label(header, text='PRODUCTION REPORT  /  CSV + AI 缺陷檔 → PDF + XLSX + PNG', style='Subtitle.TLabel').grid(row=1, column=1, sticky='w', pady=(3, 0))
        ttk.Label(header, text='v1.5', style='Subtitle.TLabel').grid(row=0, column=2, sticky='ne')

        steps = ttk.Frame(outer, style='Tech.TFrame')
        steps.grid(row=1, column=0, sticky='ew', pady=(0, 14))
        for i, (num, label, desc) in enumerate([('01', '資料來源', 'CSV 資料夾（含子資料夾）＋AI 缺陷檔'), ('02', '輸出設定', '指定報告位置與檔案'), ('03', '產生報告', '選擇 PDF / Excel / PNG')]):
            steps.columnconfigure(i, weight=1)
            card = ttk.Frame(steps, style='Card.TFrame', padding=(13, 11))
            card.grid(row=0, column=i, sticky='ew', padx=(0 if i == 0 else 6, 6 if i < 2 else 0))
            tk.Label(card, text=num, bg=PANEL, fg=CYAN, font=('Consolas', 16, 'bold')).grid(row=0, column=0, rowspan=2, padx=(0, 10))
            ttk.Label(card, text=label, style='CardTitle.TLabel').grid(row=0, column=1, sticky='w')
            ttk.Label(card, text=desc, style='CardText.TLabel').grid(row=1, column=1, sticky='w', pady=(2, 0))

        body = ttk.Frame(outer, style='Tech.TFrame')
        body.grid(row=2, column=0, sticky='nsew')
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        form = ttk.Frame(body, style='Card.TFrame', padding=(20, 18))
        form.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text='報告來源與輸出設定', style='CardTitle.TLabel').grid(row=0, column=0, columnspan=3, sticky='w', pady=(0, 15))
        self._field(form, 1, 'CSV 資料夾', self.input_dir, '選擇來源', self.choose_input)
        ttk.Label(form, text='自動搜尋所有子資料夾內的 CSV，檔名含 result 的檔案會排除。',
                  style='CardText.TLabel').grid(row=2, column=1, columnspan=2, sticky='w', padx=10, pady=(0, 2))
        self._field(form, 3, '輸出資料夾', self.output_dir, '選擇位置', self.choose_output)
        ttk.Label(form, text='報告名稱', style='Field.TLabel').grid(row=4, column=0, sticky='w', pady=7)
        ttk.Entry(form, textvariable=self.report_name, style='Tech.TEntry').grid(row=4, column=1, sticky='ew', padx=10, pady=7)
        ttk.Label(form, text='檔名與報告標題', style='CardText.TLabel').grid(row=4, column=2, sticky='w')
        ttk.Separator(form).grid(row=5, column=0, columnspan=3, sticky='ew', pady=(8, 10))
        ttk.Label(form, text='AI 缺陷檔匯入（選填｜缺陷位置/類型）', style='CardTitle.TLabel').grid(row=6, column=0, columnspan=3, sticky='w', pady=(0, 2))
        self._field(form, 7, 'AI 檔資料夾', self.ai_dir, '選擇路徑', self.choose_ai)
        ttk.Label(form, text='檔名樣式', style='Field.TLabel').grid(row=8, column=0, sticky='w', pady=7)
        ttk.Entry(form, textvariable=self.ai_pattern, style='Tech.TEntry').grid(row=8, column=1, sticky='ew', padx=10, pady=7)
        self._toggle(form, '含子資料夾', self.ai_recursive).grid(row=8, column=2, sticky='ew', pady=7)
        self.ai_hint = ttk.Label(form, text='樣式可用 * ? ，多組以 ; 分隔，例如  AI*.csv;*.ai  或  *RY1762*。Step_Code 後 4 碼 = Strip ID，用來與主報表比對。',
                                 style='CardText.TLabel', wraplength=480, justify='left')
        self.ai_hint.grid(row=9, column=0, columnspan=3, sticky='w')
        form.bind('<Configure>', lambda e: self.ai_hint.configure(wraplength=max(260, e.width - 50)))
        ttk.Separator(form).grid(row=10, column=0, columnspan=3, sticky='ew', pady=(10, 10))
        ttk.Label(form, text='輸出內容（可複選）', style='CardTitle.TLabel').grid(row=11, column=0, columnspan=3, sticky='w', pady=(0, 8))
        outputs = ttk.Frame(form, style='Card.TFrame')
        outputs.grid(row=12, column=0, columnspan=3, sticky='ew')
        for i, (tag, name, color, var) in enumerate([('PDF', '生產報告', '#FFB86B', self.out_pdf),
                                                     ('XLSX', '明細與統計', '#63E6BE', self.out_xlsx),
                                                     ('PNG', '缺點分布圖', '#7AA7FF', self.out_png)]):
            outputs.columnconfigure(i, weight=1, uniform='out')
            self._toggle(outputs, f'{tag}　{name}', var, color).grid(row=0, column=i, sticky='ew', padx=(0 if i == 0 else 5, 0 if i == 2 else 5))

        activity = ttk.Frame(body, style='Card.TFrame', padding=(18, 18))
        activity.grid(row=0, column=1, sticky='nsew', padx=(8, 0))
        activity.columnconfigure(0, weight=1)
        activity.rowconfigure(2, weight=1)
        ttk.Label(activity, text='處理狀態', style='CardTitle.TLabel').grid(row=0, column=0, sticky='w')
        self.status_badge = tk.Label(activity, text=' READY ', bg='#123753', fg=CYAN, font=('Consolas', 9, 'bold'), padx=8, pady=4)
        self.status_badge.grid(row=0, column=1, sticky='e')
        self.progress = ttk.Progressbar(activity, variable=self.progress_value, maximum=100, style='Tech.Horizontal.TProgressbar')
        self.progress.grid(row=1, column=0, columnspan=2, sticky='ew', pady=(16, 12))
        self.log = tk.Text(activity, state='disabled', wrap='word', bg='#08182A', fg='#B9D7E6', insertbackground=CYAN,
                           relief='flat', borderwidth=0, padx=12, pady=12, font=('Consolas', 9), height=12)
        self.log.grid(row=2, column=0, columnspan=2, sticky='nsew')
        scroll = ttk.Scrollbar(activity, orient='vertical', command=self.log.yview)
        scroll.grid(row=2, column=2, sticky='ns')
        self.log.configure(yscrollcommand=scroll.set)

        footer = ttk.Frame(outer, style='Tech.TFrame')
        footer.grid(row=3, column=0, sticky='ew', pady=(18, 0))
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.status, style='Status.TLabel').grid(row=0, column=0, sticky='w')
        self.generate_btn = ttk.Button(footer, text='▶ 產生報告', style='Accent.TButton', command=self.generate)
        self.generate_btn.grid(row=0, column=1, padx=(12, 8))
        ttk.Button(footer, text='關閉', style='Ghost.TButton', command=self.destroy).grid(row=0, column=2)

    def _field(self, parent, row, label, variable, button_text, command):
        ttk.Label(parent, text=label, style='Field.TLabel').grid(row=row, column=0, sticky='w', pady=7)
        ttk.Entry(parent, textvariable=variable, style='Tech.TEntry').grid(row=row, column=1, sticky='ew', padx=10, pady=7)
        ttk.Button(parent, text=button_text, style='Ghost.TButton', command=command).grid(row=row, column=2, sticky='ew', pady=7)

    def _toggle(self, parent, text, variable, color=None):
        """與 Ghost 按鈕同風格的開關鈕；勾選時以 ✔ 與強調色表示。"""
        on_bg = color or CYAN_DARK
        on_fg = NAVY if color else TEXT
        btn = tk.Checkbutton(parent, text=text, variable=variable, indicatoron=False,
                             bg=PANEL_2, fg=TEXT, selectcolor=on_bg, activebackground='#1A4262',
                             activeforeground=TEXT, relief='flat', bd=0, highlightthickness=1,
                             highlightbackground=BORDER, highlightcolor=CYAN, cursor='hand2',
                             font=('Microsoft JhengHei UI', 9), padx=12, pady=8)

        def refresh(*_):
            on = bool(variable.get())
            btn.configure(text=('✔ ' if on else '　 ') + text, fg=on_fg if on else TEXT,
                          activebackground=on_bg if on else '#1A4262',
                          activeforeground=on_fg if on else TEXT)
        variable.trace_add('write', refresh)
        refresh()
        return btn

    def choose_input(self):
        path = filedialog.askdirectory(title='選擇含 CSV 檔案的資料夾')
        if path:
            self.input_dir.set(path)
            if not self.output_dir.get():
                self.output_dir.set(str(Path(path) / '報告輸出'))
            self._log(f'[SOURCE] {path}')
            self.status.set('已選擇來源｜請確認輸出資料夾後產生報告')

    def choose_output(self):
        path = filedialog.askdirectory(title='選擇報告輸出資料夾')
        if path:
            self.output_dir.set(path)
            self._log(f'[OUTPUT] {path}')

    def choose_ai(self):
        path = filedialog.askdirectory(title='選擇 AI 缺陷檔所在資料夾')
        if path:
            self.ai_dir.set(path)
            self._log(f'[AI] {path}')

    def _log(self, text):
        self.log.configure(state='normal')
        self.log.insert('end', text + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def _drain_messages(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == 'log': self._log(payload)
                elif kind == 'progress': self.progress_value.set(payload)
                elif kind == 'done':
                    self.running = False
                    self.generate_btn.configure(state='normal')
                    self.status_badge.configure(text=' DONE ', bg='#164D48', fg=GREEN)
                    self.status.set('完成｜' + payload.split(' 輸出完成')[0] + ' 已輸出')
                    self.progress_value.set(100)
                    self._log(payload)
                    messagebox.showinfo('產生完成', payload)
                elif kind == 'error':
                    self.running = False
                    self.generate_btn.configure(state='normal')
                    self.status_badge.configure(text=' ERROR ', bg='#5A2332', fg=RED)
                    self.status.set('產生失敗｜請查看處理狀態')
                    self._log(payload)
                    messagebox.showerror('產生失敗', payload)
        finally:
            self.after(100, self._drain_messages)

    def generate(self):
        if self.running: return
        input_dir = Path(self.input_dir.get().strip())
        output_dir = Path(self.output_dir.get().strip())
        stem = self.report_name.get().strip() or '生產報告'
        if not input_dir.is_dir():
            messagebox.showwarning('資料夾未選擇', '請先選擇有效的 CSV 資料夾。'); return
        csv_files, excluded = report.find_summary_csvs(input_dir)
        if not csv_files:
            messagebox.showwarning('找不到 CSV', '指定資料夾（含子資料夾）內沒有可用的 .csv 檔案（檔名含 result 的檔案已排除）。'); return
        outputs = [k for k, v in (('pdf', self.out_pdf), ('xlsx', self.out_xlsx), ('png', self.out_png)) if v.get()]
        if not outputs:
            messagebox.showwarning('未選擇輸出', '請至少勾選一種輸出內容（PDF / XLSX / PNG）。'); return
        if any(ch in stem for ch in '/\\:*?"<>|'):
            messagebox.showwarning('檔名不合法', '報告檔名前綴不可包含 \\ / : * ? " < > |'); return
        ai_dir = self.ai_dir.get().strip()
        ai_files = []
        if ai_dir:
            if not Path(ai_dir).is_dir():
                messagebox.showwarning('AI 資料夾無效', '請選擇有效的 AI 檔資料夾，或清空此欄位略過缺陷類型。'); return
            ai_files = report.find_ai_files(ai_dir, self.ai_pattern.get(), self.ai_recursive.get())
            if not ai_files:
                messagebox.showwarning('找不到 AI 檔', f'在 AI 資料夾找不到符合「{self.ai_pattern.get()}」的檔案。'); return
        output_dir.mkdir(parents=True, exist_ok=True)
        self.running = True
        self.generate_btn.configure(state='disabled')
        self.status_badge.configure(text=' RUNNING ', bg='#164B60', fg=CYAN)
        self.progress_value.set(5)
        self.status.set('處理中｜正在解析 CSV 並產生報告')
        self._log(f'[SCAN] 找到 {len(csv_files)} 個 CSV（含子資料夾），已排除 {excluded} 個檔名含 result 的檔案')
        if ai_files:
            self._log(f'[AI] 找到 {len(ai_files)} 個 AI 檔')
        threading.Thread(target=self._worker, args=(csv_files, output_dir, stem, ai_files, outputs, input_dir), daemon=True).start()

    def _worker(self, csv_files, output_dir, stem, ai_files=(), outputs=('pdf', 'xlsx', 'png'), input_dir=None):
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(prefix='production_report_', suffix='.zip', delete=False) as tmp:
                temp_path = Path(tmp.name)
            with zipfile.ZipFile(temp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                for i, csv_path in enumerate(csv_files, 1):
                    rel = csv_path.relative_to(input_dir).as_posix() if input_dir else csv_path.name
                    zf.write(csv_path, arcname=rel)
                    self.messages.put(('progress', 5 + i / len(csv_files) * 20))
                    self.messages.put(('log', f'[READ] {rel}'))
            report.configure_paths(temp_path, output_dir, stem)
            batches, observations = report.parse_archive()
            self.messages.put(('log', f'[PARSE] {len(batches)} 批次 / {len(observations)} 筆紀錄'))
            if report.SKIPPED_FILES:
                self.messages.put(('log', f'[SKIP] {len(report.SKIPPED_FILES)} 個非檢驗摘要 CSV 已略過'))
            stats = report.build_views(batches, observations)
            if stats['unreadable_strips']:
                self.messages.put(('log', f'[WARN] 2D Code 讀取失敗（FAILED）{stats["unreadable_strips"]} 條，已視為獨立的條、不參與 AI 比對'))
            if ai_files:
                ai = report.parse_ai_files(ai_files)
                report.build_ai_stats(stats, ai)
                a = stats['ai']
                self.messages.put(('log', f'[AI] 讀入 {a["file_count"]} 檔 / {a["defect_total"]:,} 筆缺陷；'
                                          f'比對成功 {a["matched_strips"]} 條，主報表無 AI {a["summary_strips_without_ai"]} 條，'
                                          f'AI 無對應 {a["ai_ids_not_in_summary"]} 條'))
                for name, why in a['bad_files'][:5]:
                    self.messages.put(('log', f'[AI-WARN] {name}：{why}'))
                self.messages.put(('log', f'[AI] 最主要缺陷：{a["top_label"]}（{a["top_count"]:,} 筆，{a["top_pct"]:.1%}）'))
            self.messages.put(('progress', 55))
            produced = report.generate_outputs(stats, outputs, lambda v: self.messages.put(('progress', v)))
            names = {'pdf': 'PDF', 'xlsx': 'Excel', 'png': 'PNG'}
            label = '、'.join(names[k] for k in ('pdf', 'xlsx', 'png') if k in outputs)
            self.messages.put(('done', f'{label} 輸出完成：\n' + '\n'.join(str(path) for path in produced)))
        except Exception as exc:
            details = ''.join(traceback.format_exception_only(type(exc), exc)).strip()
            self.messages.put(('error', f'產生報告時發生錯誤：{details}\n請確認 CSV 欄位格式與檔案內容。'))
        finally:
            if temp_path:
                try: temp_path.unlink(missing_ok=True)
                except Exception: pass


if __name__ == '__main__':
    ReportApp().mainloop()
